import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import PortfolioSticky from "@/components/portfolio/PortfolioSticky";
import FadeUp from "@/components/motion/FadeUp";

export default function Index() {
  return (
    <div className="relative">
      {/* Hero */}
      <section id="home" className="container relative flex min-h-[80svh] flex-col items-center gap-10 py-24 md:flex-row md:items-end">
        <div className="absolute inset-0 -z-10 overflow-hidden">
          <div className="absolute left-1/2 top-10 size-[700px] -translate-x-1/2 rounded-full bg-gradient-to-tr from-amber-400/20 to-yellow-300/0 blur-3xl" />
        </div>
        <div className="flex-1">
          <FadeUp>
            <div className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs text-white/70 backdrop-blur">
              <span className="size-2 rounded-full bg-emerald-400" /> Available for new projects
            </div>
          </FadeUp>
          <FadeUp delay={0.05}>
            <h1 className="mt-4 text-4xl font-extrabold leading-tight tracking-tight md:text-6xl">
              I'm <span className="bg-gradient-to-r from-amber-300 via-yellow-300 to-amber-400 bg-clip-text text-transparent">Shahe Aalam Ansari</span>
            </h1>
          </FadeUp>
          <FadeUp delay={0.1}>
            <p className="mt-4 max-w-xl text-white/70">
              Frontend engineer and B.Tech student crafting modern, fast, and accessible web experiences. I build polished products with great UX and clean code.
            </p>
          </FadeUp>
          <FadeUp delay={0.15}>
            <div className="mt-6 flex flex-wrap items-center gap-3">
              <Button className="bg-amber-400 text-black hover:bg-amber-300" asChild>
                <a href="#projects">Explore My Work</a>
              </Button>
              <Button variant="outline" asChild className="border-white/20 text-white hover:bg-white/10">
                <a href="#contact">Let’s Connect</a>
              </Button>
            </div>
          </FadeUp>
          <FadeUp delay={0.2}>
            <div className="mt-8 flex flex-wrap gap-2">
              {['React', 'TypeScript', 'Tailwind', 'Node.js', 'DSA'].map((s) => (
                <Badge key={s} className="bg-white/10 text-white hover:bg-white/20">{s}</Badge>
              ))}
            </div>
          </FadeUp>
        </div>
        <div className="flex-1">
          <FadeUp delay={0.08}>
            <div className="mx-auto aspect-square max-w-[420px] overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-br from-zinc-900 to-zinc-800 p-3 shadow-[0_0_0_1px_rgba(255,255,255,0.06)]">
              <div className="relative h-full w-full overflow-hidden rounded-2xl ring-1 ring-white/10">
                <img
                  src="https://shahe-aalam-ansari.netlify.app/images/shaheimg1.png"
                  alt="Shahe Aalam Ansari"
                  className="h-full w-full object-cover"
                />
              </div>
            </div>
          </FadeUp>
        </div>
      </section>

      {/* About */}
      <section id="about" className="container py-20">
        <div className="grid items-center gap-10 md:grid-cols-2">
          <div className="order-2 md:order-1">
            <h2 className="text-2xl font-semibold tracking-tight md:text-3xl">About</h2>
            <p className="mt-4 text-white/70">
              I love building things for the web—from landing pages to dynamic apps. My focus is on performance, delightful interactions, and maintainable code. When I'm not coding, I enjoy sharpening my problem-solving skills with DSA.
            </p>
            <dl className="mt-6 grid grid-cols-2 gap-4 text-sm text-white/70">
              <div>
                <dt className="text-white/50">Study</dt>
                <dd className="font-medium">B.Tech (Engineering)</dd>
              </div>
              <div>
                <dt className="text-white/50">Role</dt>
                <dd className="font-medium">Frontend Engineer</dd>
              </div>
              <div>
                <dt className="text-white/50">Focus</dt>
                <dd className="font-medium">React, TypeScript, UX</dd>
              </div>
              <div>
                <dt className="text-white/50">Location</dt>
                <dd className="font-medium">India</dd>
              </div>
            </dl>
          </div>
          <div className="order-1 md:order-2">
            <Card className="border-white/10 bg-white/5">
              <CardHeader>
                <CardTitle>Core Skills</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="grid grid-cols-2 gap-3 text-sm">
                  {[
                    { label: "C", value: 80 },
                    { label: "CSS3", value: 90 },
                    { label: "Express", value: 82 },
                    { label: "HTML5", value: 90 },
                    { label: "Java", value: 78 },
                    { label: "JavaScript", value: 92 },
                    { label: "MongoDB", value: 85 },
                    { label: "MySQL", value: 84 },
                    { label: "NestJS", value: 79 },
                    { label: "Node.js", value: 86 },
                    { label: "OpenCV", value: 77 },
                    { label: "Pandas", value: 81 },
                    { label: "Python", value: 88 },
                    { label: "React", value: 91 },
                    { label: "Tailwind", value: 90 },
                  ].map((s) => (
                    <li key={s.label} className="space-y-2">
                      <div className="flex items-center justify-between text-white/80">
                        <span>{s.label}</span>
                        <span>{s.value}%</span>
                      </div>
                      <div className="h-2 overflow-hidden rounded-full bg-white/10">
                        <div
                          className="h-full rounded-full bg-amber-400"
                          style={{ width: `${s.value}%` }}
                        />
                      </div>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Resume */}
      <section id="resume" className="container py-20">
        <div className="relative mb-10 text-center">
          <h2 className="text-3xl font-extrabold md:text-4xl">Resume</h2>
          <div className="pointer-events-none absolute inset-0 -z-10 flex items-center justify-center">
            <span className="select-none text-7xl font-black tracking-tighter text-white/5 md:text-8xl">Resume</span>
          </div>
          <p className="mx-auto mt-3 max-w-2xl text-white/70">
            Recent Computer Science pursuing CSE (AI & ML), passionate about leveraging AI‑driven solutions to solve complex problems. Skilled in programming, data analysis, and innovative problem‑solving.
          </p>
        </div>
        <div className="grid gap-6 lg:grid-cols-2">
          <div className="rounded-2xl border border-white/10 bg-white/5 p-6">
            <div className="text-amber-300 font-semibold">2027–2023</div>
            <h3 className="mt-2 text-xl font-semibold">Bachelor of Technology</h3>
            <p className="mt-2 text-sm text-white/60">Bansal Institute of Engineering & Technology, Lucknow</p>
            <p className="mt-3 text-sm">SGPA: 7.6</p>
          </div>
          <div className="rounded-2xl border border-white/10 bg-white/5 p-6">
            <div className="text-amber-300 font-semibold">2021–2019</div>
            <h3 className="mt-2 text-xl font-semibold">Intermidiate School</h3>
            <p className="mt-2 text-sm text-white/60">Sumitra Devi Inter College, Paikauli (Deoria)</p>
            <p className="mt-3 text-sm">Grade: First class distinction.</p>
          </div>
          <div className="lg:col-span-2 rounded-2xl border border-white/10 bg-white/5 p-6">
            <div className="text-amber-300 font-semibold">2019–2017</div>
            <h3 className="mt-2 text-xl font-semibold">Higher Secondary School</h3>
            <p className="mt-2 text-sm text-white/60">B.D. Vidya Mandir Intermidiate College, Hate Khas (Deoria)</p>
            <p className="mt-3 text-sm">Grade: First class distinction.</p>
          </div>
        </div>
        <div className="mt-8 flex justify-center">
          <button
            onClick={() => {
              const cvUrl = "";
              if (!cvUrl) {
                import("sonner").then(({ toast }) => toast("Please send your CV URL to enable download"));
              } else {
                window.open(cvUrl, "_blank");
              }
            }}
            className="inline-flex items-center rounded-xl border border-white/20 bg-white/10 px-6 py-3 text-sm font-semibold text-white hover:bg-white/20"
          >
            Download CV
            <svg className="ml-2 size-4" viewBox="0 0 24 24" fill="none"><path d="M7 17l5 5 5-5M12 12v10M19 12V5a2 2 0 00-2-2H7a2 2 0 00-2 2v7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
          </button>
        </div>
      </section>

      {/* Projects */}
      <section id="projects" className="container py-20">
        <div className="mb-8">
          <p className="text-xs uppercase tracking-widest bg-gradient-to-r from-emerald-300 to-sky-300 bg-clip-text text-transparent">Real-world Results</p>
          <h2 className="text-2xl font-semibold tracking-tight md:text-3xl">Featured Projects</h2>
          <p className="mt-2 text-white/60">Swipe through the wallet-style showcase, inspired by aftab-portfolio.</p>
        </div>

        {/* Sticky wallet-like showcase */}
        <PortfolioSticky
          items={[
            {
              company: "Personal Projects",
              year: "2024",
              title: "MirrorTube",
              results: [
                { title: "User can create and manage their channel" },
                { title: "Upload/delete videos, comments, like/dislike" },
                { title: "Play videos and subscribe to channels" },
                { title: "Light/dark theme for convenience" },
              ],
              link1: "https://65e89fcf6d9dcd1e4856f8bd--bright-cheesecake-57616f.netlify.app/",
              link2: "https://github.com/Aftab-alam-73/YouTube_Clone",
              image: "/placeholder.svg",
            },
            {
              company: "Personal Projects",
              year: "2024",
              title: "BookMyFlight",
              results: [
                { title: "Admin can add flights, update status" },
                { title: "Users subscribe for real-time updates" },
                { title: "Track flights by number" },
                { title: "Real-time updates via email/SMS/notification" },
              ],
              link1: "https://github.com/Aftab-alam-73/BookMyFlight",
              link2: "https://github.com/Aftab-alam-73/BookMyFlight",
              image: "/placeholder.svg",
            },
            {
              company: "Personal Projects",
              year: "2024",
              title: "Dark Saas Landing Page",
              results: [
                { title: "Enhanced UX by 40%" },
                { title: "Improved speed by 50%" },
                { title: "Increased mobile traffic by 35%" },
              ],
              link1: "https://saas-website-dark-landing-page-tau.vercel.app/",
              link2: "https://github.com/Aftab-alam-73/Saas_Landing_Page",
              image: "/placeholder.svg",
            },
            {
              company: "Personal Project",
              year: "2024",
              title: "My Schedulerr",
              results: [
                { title: "Manage your time effectively" },
                { title: "Create events, set availability, booking" },
              ],
              link1: "https://my-schedulerr.vercel.app/",
              link2: "https://github.com/Aftab-alam-73/Event_Scheduler",
              image: "/placeholder.svg",
            },
            {
              company: "Personal Project",
              year: "2024",
              title: "TabBlock",
              results: [
                { title: "Secure Authentication with Google/Firebase" },
                { title: "Real-time conflict handling with Socket.IO" },
                { title: "Activity logging for monitoring" },
              ],
              link1: "https://zingy-piroshki-d17470.netlify.app/",
              link2: "https://github.com/Aftab-alam-73/TabBlock",
              image: "/placeholder.svg",
            },
          ]}
        />
      </section>

      {/* Contact */}
      <section id="contact" className="container pb-24 pt-10">
        <div className="rounded-2xl border border-white/10 bg-white/5 p-8 text-center">
          <h2 className="text-2xl font-semibold tracking-tight md:text-3xl">Let’s work together</h2>
          <p className="mx-auto mt-2 max-w-xl text-white/70">
            Have an idea or a role in mind? I’m open to freelance and internship opportunities.
          </p>
          <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
            <Button className="bg-amber-400 text-black hover:bg-amber-300" asChild>
              <a href="#home">Back to top</a>
            </Button>
            <Button variant="outline" className="border-white/20 text-white hover:bg-white/10" asChild>
              <a href="#projects">See projects</a>
            </Button>
          </div>
          <div className="mt-6 text-sm text-white/50">
            <p>Based in India · Portfolio built with React + Tailwind</p>
          </div>
        </div>
      </section>
    </div>
  );
}
