import { useLocation } from "react-router-dom";
import { useEffect } from "react";

const NotFound = () => {
  const location = useLocation();

  useEffect(() => {
    console.error(
      "404 Error: User attempted to access non-existent route:",
      location.pathname,
    );
  }, [location.pathname]);

  return (
    <div className="min-h-[60svh] container flex items-center justify-center">
      <div className="text-center">
        <h1 className="text-6xl font-extrabold mb-2 tracking-tight">404</h1>
        <p className="text-base text-white/60 mb-6">This page could not be found.</p>
        <a href="/" className="inline-flex items-center rounded-md bg-amber-400 px-4 py-2 text-sm font-semibold text-black hover:bg-amber-300">
          Return to Home
        </a>
      </div>
    </div>
  );
};

export default NotFound;
