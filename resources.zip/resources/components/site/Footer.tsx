export default function Footer() {
  return (
    <footer className="border-t border-white/10 bg-black/50">
      <div className="container py-8 text-center text-sm text-white/60">
        <p>
          © {new Date().getFullYear()} Shahe Aalam Ansari · Crafted with React & Tailwind
        </p>
      </div>
    </footer>
  );
}
