import { useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { Menu, X } from "lucide-react";

const links = [
  { href: "#home", label: "Home" },
  { href: "#about", label: "About" },
  { href: "#resume", label: "Resume" },
  { href: "#projects", label: "Projects" },
  { href: "#contact", label: "Contact" },
];

export default function Header() {
  const [open, setOpen] = useState(false);
  const nav = useNavigate();
  const location = useLocation();

  const handleAnchor = (href: string) => (e: React.MouseEvent) => {
    e.preventDefault();
    if (location.pathname !== "/") {
      nav(`/${href}`);
    } else {
      const el = document.querySelector(href);
      el?.scrollIntoView({ behavior: "smooth", block: "start" });
    }
    setOpen(false);
  };

  return (
    <header className="sticky top-0 z-50 border-b border-white/10 bg-black/40 backdrop-blur-md">
      <div className="container flex h-16 items-center justify-between">
        <Link to="/" className="flex items-center gap-2">
          <div className="size-7 rounded-md bg-gradient-to-tr from-amber-400 via-yellow-300 to-amber-500 ring-1 ring-white/20" />
          <span className="text-sm font-semibold tracking-wider">SHAHE AALAM</span>
        </Link>
        <nav className="hidden md:flex items-center gap-6">
          <div className="flex items-center rounded-full border border-white/15 bg-white/10 p-1 shadow-inner shadow-black/30">
            {links.map((l) => {
              const isActive = (location.hash || "#home") === l.href;
              return (
                <a
                  key={l.href}
                  href={l.href}
                  onClick={handleAnchor(l.href)}
                  className={cn(
                    "rounded-full px-4 py-2 text-sm transition-colors",
                    isActive
                      ? "bg-white text-black shadow"
                      : "text-white/80 hover:text-white hover:bg-white/10",
                  )}
                >
                  {l.label}
                </a>
              );
            })}
          </div>
          <Button asChild className="bg-amber-400 text-black hover:bg-amber-300">
            <a href="#contact" onClick={handleAnchor("#contact")}>Contact</a>
          </Button>
        </nav>
        <button
          className="md:hidden inline-flex items-center justify-center rounded-md p-2 text-white/80 hover:bg-white/10"
          aria-label="Toggle menu"
          onClick={() => setOpen((v) => !v)}
        >
          {open ? <X className="size-6" /> : <Menu className="size-6" />}
        </button>
      </div>
      {open && (
        <div className="md:hidden border-t border-white/10 bg-black/70">
          <div className="container py-2">
            <div className="flex flex-col gap-2 py-2">
              <div className="rounded-full border border-white/15 bg-white/10 p-1">
                {links.map((l) => {
                  const isActive = (location.hash || "#home") === l.href;
                  return (
                    <a
                      key={l.href}
                      href={l.href}
                      onClick={handleAnchor(l.href)}
                      className={cn(
                        "block rounded-full px-4 py-2 text-sm",
                        isActive
                          ? "bg-white text-black shadow"
                          : "text-white/80 hover:text-white hover:bg-white/10",
                      )}
                    >
                      {l.label}
                    </a>
                  );
                })}
              </div>
              <Button asChild className="bg-amber-400 text-black hover:bg-amber-300">
                <a href="#contact" onClick={handleAnchor("#contact")}>Contact</a>
              </Button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
