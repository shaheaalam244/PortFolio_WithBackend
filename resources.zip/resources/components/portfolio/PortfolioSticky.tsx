import { Button } from "@/components/ui/button";

export type StickyProject = {
  company: string;
  year: string;
  title: string;
  results: { title: string }[];
  link1?: string;
  link2?: string;
  image?: string;
};

export default function PortfolioSticky({ items }: { items: StickyProject[] }) {
  return (
    <div className="relative">
      <div className="flex flex-col gap-20 md:gap-24">
        {items.map((project, projectIndex) => (
          <article
            key={project.title}
            className="sticky overflow-hidden rounded-3xl border border-white/12 bg-card px-8 pt-8 shadow-[0_0_0_1px_rgba(255,255,255,0.06),0_10px_40px_rgba(0,0,0,0.4)] md:px-10 md:pt-12 lg:px-20 lg:pt-16"
            style={{ top: `calc(72px + ${projectIndex * 40}px)` }}
          >
            <div
              className="pointer-events-none absolute inset-0 -z-10 opacity-10"
              style={{
                backgroundImage:
                  "radial-gradient(60% 50% at 10% 0%, rgba(255,189,57,0.2), transparent 60%), radial-gradient(70% 60% at 100% 0%, rgba(255,189,57,0.15), transparent 60%)",
              }}
            />

            <div className="lg:grid lg:grid-cols-2 lg:gap-16">
              <div className="lg:pb-16">
                <div className="bg-gradient-to-r from-emerald-300 to-sky-400 inline-flex gap-2 bg-clip-text text-sm font-bold uppercase tracking-widest text-transparent">
                  <span>{project.company}</span>
                  <span>•</span>
                  <span>{project.year}</span>
                </div>
                <h3 className="mt-2 font-serif text-2xl md:mt-5 md:text-4xl">{project.title}</h3>
                <hr className="mt-4 border-t-2 border-white/5 md:mt-5" />
                <ul className="mt-4 flex flex-col gap-4 text-sm text-white/60 md:mt-5 md:text-base">
                  {project.results.map((r) => (
                    <li key={r.title} className="flex gap-2">
                      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" className="mt-0.5 text-amber-400">
                        <path d="M20 6L9 17l-5-5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                      </svg>
                      <span>{r.title}</span>
                    </li>
                  ))}
                </ul>
                <div className="mt-6 flex flex-wrap gap-3">
                  {project.link1 && (
                    <Button asChild className="bg-white text-black hover:bg-white/90">
                      <a href={project.link1} target="_blank" rel="noreferrer">
                        Visit Live Site
                        <span className="ml-2">↗</span>
                      </a>
                    </Button>
                  )}
                  {project.link2 && (
                    <Button variant="outline" asChild className="border-white/20 text-white hover:bg-white/10">
                      <a href={project.link2} target="_blank" rel="noreferrer">
                        Visit GitHub
                        <span className="ml-2">↗</span>
                      </a>
                    </Button>
                  )}
                </div>
              </div>
              <div className="relative">
                <div className="mt-8 overflow-hidden rounded-2xl border border-white/10 bg-gradient-to-b from-zinc-800 to-zinc-900 lg:absolute lg:mt-0 lg:h-full lg:w-auto lg:max-w-none">
                  <div className="aspect-[16/10] w-full lg:h-full lg:aspect-auto">
                    {project.image ? (
                      <img src={project.image} alt={project.title} className="h-full w-full object-cover" />
                    ) : (
                      <div className="flex h-full w-full items-center justify-center text-white/40">No preview</div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
}
