import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { motion } from "framer-motion";
import { useState } from "react";

export type ProjectItem = {
  title: string;
  description: string;
  image?: string;
  alt?: string;
  features?: string[];
  liveUrl?: string;
  githubUrl?: string;
  badge?: string; // e.g., Personal Project · 2024
};

export default function ProjectStack({ items }: { items: ProjectItem[] }) {
  const [active, setActive] = useState(0);
  const GAP = 88;
  return (
    <div className="relative">
      <div>
        {items.map((item, idx) => (
          <motion.article
            key={item.title}
            initial={{ opacity: 0, y: 72 }}
            animate={{ y: idx < active ? -((active - idx) * GAP) : 0, opacity: idx < active ? 0.75 : 1 }}
            viewport={{ once: false, amount: 0.3 }}
            transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
            whileHover={{ y: idx < active ? -((active - idx) * GAP) : -6 }}
            onClick={() => setActive(idx)}
            style={{ zIndex: idx === active ? 999 : items.length - idx, position: "relative", cursor: "pointer" }}
            className={cn(
              "relative overflow-hidden rounded-3xl border border-white/12 bg-white/[0.04] p-6 md:p-10",
              "shadow-[0_0_0_1px_rgba(255,255,255,0.06),0_10px_40px_rgba(0,0,0,0.4)]",
              idx > 0 ? "-mt-16 md:-mt-24" : "mt-0",
            )}
          >
            {/* stacked header layers */}
            <div className="pointer-events-none absolute inset-x-6 -top-6 hidden h-6 rounded-2xl border border-white/10 bg-white/[0.03] md:block" />
            <div className="pointer-events-none absolute inset-x-8 -top-10 hidden h-6 rounded-2xl border border-white/10 bg-white/[0.02] md:block" />
            <div className="pointer-events-none absolute inset-x-10 -top-14 hidden h-6 rounded-2xl border border-white/10 bg-white/[0.02] md:block" />

            {/* content */}
            <div className="grid items-center gap-8 md:grid-cols-2">
              <div>
                {item.badge && (
                  <p className="mb-3 text-xs uppercase tracking-widest text-white/70">
                    {item.badge}
                  </p>
                )}
                <h3 className="text-2xl font-semibold md:text-3xl">{item.title}</h3>
                <p className="mt-2 text-white/70">{item.description}</p>
                {item.features && item.features.length > 0 && (
                  <ul className="mt-4 space-y-2 text-sm text-white/70">
                    {item.features.map((f) => (
                      <li key={f} className="flex items-start gap-2">
                        <span className="mt-1 inline-block size-1.5 rounded-full bg-amber-400" />
                        <span>{f}</span>
                      </li>
                    ))}
                  </ul>
                )}
                <div className="mt-6 flex flex-wrap gap-3">
                  {item.liveUrl && (
                    <Button asChild className="bg-amber-400 text-black hover:bg-amber-300">
                      <a href={item.liveUrl} target="_blank" rel="noreferrer">Visit Live Site</a>
                    </Button>
                  )}
                  {item.githubUrl && (
                    <Button variant="outline" asChild className="border-white/20 text-white hover:bg-white/10">
                      <a href={item.githubUrl} target="_blank" rel="noreferrer">Visit GitHub</a>
                    </Button>
                  )}
                </div>
              </div>
              <div>
                <div className="overflow-hidden rounded-2xl border border-white/10 bg-gradient-to-b from-zinc-800 to-zinc-900">
                  <div className="aspect-[16/10] w-full">
                    {item.image ? (
                      // eslint-disable-next-line jsx-a11y/alt-text
                      <img
                        src={item.image}
                        alt={item.alt ?? item.title}
                        className="h-full w-full object-cover"
                      />
                    ) : (
                      <div className="flex h-full w-full items-center justify-center text-white/40">No preview</div>
                    )}
                  </div>
                </div>
              </div>
            </div>

            {/* highlight */}
            <div className="pointer-events-none absolute -left-24 top-0 size-[420px] -translate-y-1/2 rounded-full bg-amber-400/10 blur-3xl" />
          </motion.article>
        ))}
      </div>
      <div className="mt-6 flex items-center justify-center gap-3">
        <Button
          variant="outline"
          className="border-white/20 text-white hover:bg-white/10"
          onClick={() => setActive((a) => Math.max(0, a - 1))}
        >
          Previous
        </Button>
        <Button
          className="bg-amber-400 text-black hover:bg-amber-300"
          onClick={() => setActive((a) => Math.min(items.length - 1, a + 1))}
        >
          Next
        </Button>
      </div>
    </div>
  );
}
