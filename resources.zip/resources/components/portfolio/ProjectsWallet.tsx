import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { motion } from "framer-motion";

export interface WalletProject {
  title: string;
  description: string;
  tags: string[];
  link?: string;
  image?: string;
  alt?: string;
}

interface Props {
  projects: WalletProject[];
}

export default function ProjectsWallet({ projects }: Props) {
  return (
    <div className="relative overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-br from-zinc-950 to-zinc-900 p-6 shadow-[0_0_0_1px_rgba(255,255,255,0.06)]">
      <div className="pointer-events-none absolute -left-40 -top-40 size-[500px] rounded-full bg-amber-400/10 blur-3xl" />
      <div className="flex items-center justify-between gap-4">
        <div>
          <p className="text-xs uppercase tracking-widest bg-gradient-to-r from-emerald-300 to-sky-300 bg-clip-text text-transparent">Real-world Results</p>
          <h3 className="text-xl font-semibold">Project Wallet</h3>
          <p className="text-sm text-white/60">Swipe through featured builds</p>
        </div>
        <div className="hidden sm:flex gap-2">
          <div className="h-8 w-8 rounded-full bg-emerald-400/20 ring-1 ring-emerald-300/40" />
          <div className="h-8 w-8 rounded-full bg-sky-400/20 ring-1 ring-sky-300/40 -ml-3" />
        </div>
      </div>
      <div className="mt-6 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {projects.map((p, i) => (
          <motion.article
            key={p.title}
            initial={{ opacity: 0, y: 32 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1], delay: i * 0.06 }}
            whileHover={{ y: -4 }}
            className={cn(
              "group relative overflow-hidden rounded-2xl border border-white/10 bg-white/[0.04] p-4 transition-transform will-change-transform",
              i % 3 === 0 && "rotate-[-1.2deg]",
              i % 3 === 1 && "rotate-[0.6deg]",
              i % 3 === 2 && "rotate-[-0.4deg]",
            )}
          >
            <div className="absolute inset-0 bg-[radial-gradient(600px_200px_at_50%_-10%,hsl(var(--primary)/0.15),transparent)] opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
            <div className="relative">
              {p.image && (
                <div className="mb-3 overflow-hidden rounded-xl border border-white/10">
                  <div className="aspect-[16/10] w-full bg-black/30">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src={p.image} alt={p.alt ?? p.title} className="h-full w-full object-cover" />
                  </div>
                </div>
              )}
              <div className="mb-3 flex items-center gap-2">
                <div className="size-8 rounded-lg bg-amber-400 text-black grid place-content-center font-bold">{i + 1}</div>
                <h4 className="text-base font-semibold tracking-tight">{p.title}</h4>
              </div>
              <p className="text-sm text-white/70 line-clamp-2">{p.description}</p>
              <div className="mt-3 flex flex-wrap gap-2">
                {p.tags.map((t) => (
                  <span key={t} className="rounded-full border border-white/10 bg-white/5 px-2 py-0.5 text-[11px] text-white/70">{t}</span>
                ))}
              </div>
              <div className="mt-4">
                {p.link ? (
                  <Button asChild className="h-8 bg-amber-400 text-black hover:bg-amber-300">
                    <a href={p.link} target="_blank" rel="noreferrer">Visit</a>
                  </Button>
                ) : (
                  <Button disabled className="h-8 bg-white/10 text-white">Coming soon</Button>
                )}
              </div>
            </div>
          </motion.article>
        ))}
      </div>
    </div>
  );
}
