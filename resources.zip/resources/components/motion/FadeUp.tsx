import { motion, MotionProps } from "framer-motion";
import { PropsWithChildren } from "react";

interface FadeUpProps extends PropsWithChildren, MotionProps {
  delay?: number;
}

export default function FadeUp({ children, delay = 0, ...rest }: FadeUpProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 28 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.2 }}
      transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1], delay }}
      {...rest}
    >
      {children}
    </motion.div>
  );
}
